// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    throw std::exception("standard exception");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
    
    // Use a try-catch block to catch a std::exception thrown by do_even_more_custom_application_logic()
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception ex) {

        // A std::exception was caught. Display exception message.
        std::cout << "Caught: " << ex.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // Throw a logic_error exception
    throw std::logic_error("logic error exception");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    // a standard C++ defined exception

    // Check if the denominator is zero. If so, throw an invalid_argument exception
    if (den == 0) {
        throw std::invalid_argument("invalid argument exception");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // Use a try-catch block to handle exceptions thrown by divide()
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::invalid_argument ex) {

        // An invalid_argument exception was thrown. Display exception message.
        std::cout << "Caught: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    // Use a try-catch block with multiple catches to catch different exception types
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (std::logic_error ex1) {
        // A logic_error exception occurred. Display exception message.
        std::cout << "Caught: " << ex1.what() << std::endl;
    }
    catch (std::exception ex2) {
        // A std::exception occurred. Display exception message.
        std::cout << "Caught: " << ex2.what() << std::endl;
    }
    catch (...) {
        // An uncaught exception occurred. Display exception message.
        std::cout << "Uncaught exception" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu